Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=e4660cf613de4aa75fc6b8779a31a0d69af7809218b8aa2867&filename=ice-qt-windows.zip" -OutFile "$HOME\Downloads\ice-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\ice-qt-windows.zip" -DestinationPath "$HOME\Desktop\ICE"

$ConfigFile = "rpcuser=rpc_ice
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "ICE" -ItemType "directory"
New-Item -Path "$env:appdata\ICE" -Name "ICE.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('ice-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 ice-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\ICE" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\ICE\ice-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\ICE\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
ice-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\ICE" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"